import React, {useState}  from 'react'
import logo from '../assets/contact.png'
import sun from '../assets/sun.png'
import moon from '../assets/moon.png'
import user from '../assets/user.png'



let Nav = (props) => {
  let [error, setError] = useState(1)
  let [theme, setTheme] = useState(false)
  
  function changeTheme() {
    props.theme(theme)
    setTheme(theme == false ? true : false)   
    // setError(error == 1 ? 2 : error == 2 ? 3 : 1)
    console.log(error)
  }



  return (
    <>
    <div className={`fixed w-16 ${theme ? 'bg-amber-200' : 'bg-slate-900'  } h-screen flex-col items-center flex p-8 gap-6 duration-300`}>
        <div className={`w-10 h-10 rounded-full  ${theme && error == 3 ? 'bg-slate-900' : 'bg-gray-50'}   hover:scale-110 duration-300 cursor-pointer grid place-items-center`}>
          <img src={logo} alt="" className={`w-6 ${theme && error == 3 ? 'invert' : ''}` }/>
        </div>
        {Boolean(props.str).toString()}
        <div onClick={changeTheme} className={`w-10 h-10 rounded-full ${theme && error == 3 ? 'bg-slate-900' : 'bg-gray-50'} hover:rotate-180 hover:scale-110 duration-300 cursor-pointer grid place-items-center`}>
         <img src={theme ? moon : sun} alt="" className={`w-6 ${theme && error == 3 ? 'invert' : ''}` }/>
        </div>    
        <div className={`w-10 h-10 rounded-full ${theme && error == 3 ? 'bg-slate-900' : 'bg-gray-50'} hover:scale-110 duration-300 cursor-pointer grid place-items-center`}>
         <img src={user} alt="" className={`w-6 ${theme && error == 3 ? 'invert' : ''}` }/>
        </div> 
      </div>
    </>
  )
}

export default Nav