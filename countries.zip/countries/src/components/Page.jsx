import React, {useState, useEffect} from 'react'
import axios from 'axios'
// import React, {useState}  from 'react'
import logo from '../assets/contact.png'
import sun from '../assets/sun.png'
import moon from '../assets/moon.png'
import user from '../assets/user.png'


function Page(props) {

  let [error, setError] = useState(1)
  let [theme, setTheme] = useState(false)
  
  function changeTheme() {
    props.mtheme(theme)
    setTheme(theme == false ? true : false)   
    // setError(error == 1 ? 2 : error == 2 ? 3 : 1)
    console.log(error)
  }

let change = (e) => {
    setMsg(e.target.value)
  }

  const [countryData, setCountryData] = useState([]);
  
  const [msg, setMsg] = useState('')

  const [flag, setFlag] = useState(false)


  function onFlag() {
    setFlag(flag == false ? true : false)
  }

   
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(msg);
    // console.log(Boolean(props.theme).toString())
  };
  
  const [herror, setHerror] = useState(false)
  

  useEffect(() => {
    axios.get(`https://restcountries.com/v2/name/${msg}?fulltext=true`)
        .then((response) => setCountryData(response.data))
        .catch((error) => console.log(error));
    }, []);
   



    function numberWithCommas(x) {
      var parts = x.toString().split(".");
      parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,".");
      return parts.join(",");
    }

    function damn() {
      setHerror(herror == false ? true : true)
    }
  
  

  

  return (
    <div className="w-screen h-screen flex flex-row">
      <div className={`fixed w-16 ${theme ? 'bg-amber-200' : 'bg-slate-900'  } h-screen flex-col items-center flex p-8 gap-6 duration-300`}>
        <div className={`w-10 h-10 rounded-full  ${theme && error == 3 ? 'bg-slate-900' : 'bg-gray-50'}   hover:scale-110 duration-300 cursor-pointer grid place-items-center`}>
          <img src={logo} alt="" className={`w-6 ${theme && error == 3 ? 'invert' : ''}` }/>
        </div>
        {/* {Boolean(props.str).toString()} */}
        <div onClick={changeTheme} className={`w-10 h-10 rounded-full ${theme && error == 3 ? 'bg-slate-900' : 'bg-gray-50'} hover:rotate-180 hover:scale-110 duration-300 cursor-pointer grid place-items-center`}>
         <img src={theme ? moon : sun} alt="" className={`w-6 ${theme && error == 3 ? 'invert' : ''}` }/>
        </div>    
        <div className={`w-10 h-10 rounded-full ${theme && error == 3 ? 'bg-slate-900' : 'bg-gray-50'} hover:scale-110 duration-300 cursor-pointer grid place-items-center`}>
         <img src={user} alt="" className={`w-6 ${theme && error == 3 ? 'invert' : ''}` }/>
        </div> 
      </div>
    


    <div className={`page flex flex-col w-full h-screen items-center p-10 pl-24 md:p-16`}>
      <form action="" className='w-3/4 flex relative' onSubmit={handleSubmit}>
        <label htmlFor="" className='w-full'>
          <input type="text" name="" placeholder='Search A Country...' value={msg} onChange={change} className={`w-full h-10 rounded-lg  p-5  ${theme == true ? 'bg-gray-300 placeholder-black text-black' : ''}`}/>
        </label>
        <button type='submit' onClick={damn} className='w-10 md:w-20 h-10 bg-cyan-900 absolute right-0 rounded-r-lg text-white hover:brightness-150 duration-300'>Go !</button>
      </form>
           
          <div  className={`w-full  md:w-11/12 ${herror == true ? 'h-fit' : 'h-5/6'} m-auto flex flex-row mt-5  rounded-xl bg-cyan-500 bg-opacity-30 shadow-2xl p-3`}>

            {countryData.map((country) => (           
              <div key={country.alpha3Code} className='w-full m-auto h-full flex flex-row text-gray-50'>
                <div className={`w-1/3 overflow-hidden ${theme == true ? 'text-slate-700' : 'text-white'}  relative h-full text-center shadow-lg flex flex-col items-center bg-cyan-700 bg-opacity-30 rounded-xl p-5 gap-10 bg-no-repeat bg-cover bg-center bg-fixed`}>
                  <img src={country.flags.svg} alt="" onClick={onFlag} className={`shadow-2xl z-10 cursor-pointer hover:rounded-xl duration-100`} /* style={{width: `${flag == true ? '70vw' : ''}`, position: `${flag == true ? 'absolute' : ''}`, margin: `${flag == true ? 'auto' : ''}`}} *//>
                  <h1 className='text-xl z-10 md:text-3xl drop-hadow-2xl'>
                    {country.name}
                  </h1>  
                  {/* <img src={country.flags.svg} alt="" className=' rotate-45 brightness-50 z-0' style={{height: '500%', width: '600%'}}/>               */}
                </div>
                <div className={`flex ${theme == true ? 'text-slate-700' : 'text-white'} flex-col text-lg md:text-2xl p-3 gap-2 md:gap-4 md:p-3 `}>
                  <p>Native name:  {country.nativeName}</p>
                  
                  <p>Capital:  {country.capital}</p>
              
                  <p>Population:  {numberWithCommas((country.population).toFixed(0))}</p>

                  <p>
                    <a href="https://en.wikipedia.org/wiki/Gini_coefficient" className='underline'>Gini</a> (equality among citizens): {country.gini}
                  </p>

                  <p>Spoken languages: {country.languages[0].name}</p>

                  <p>Demonym:  {country.demonym}</p>

                  <p>Timezones:  {country.timezones.join(', ')}</p>

                  <p>Currency: {country.currencies[0].name}</p>
                  
                  <p>Region: { country.region}, { country.subregion}</p>

                  <p>Area:  {numberWithCommas((country.area).toFixed(0))}km</p>

                  <p>Borders: {country.borders.join(', ')}</p>

                  <p>Is independent:  {country.independent.toString() == 'true' ? 'Yes, it is' : 'No, it isn`t'}</p>


                </div>
                
                
              
              </div>

              ))}
          
          </div>
       
    </div>
    </div>
  )
}

export default Page