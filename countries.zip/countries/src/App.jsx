import React, { useState } from 'react'
import './App.css'
import Nav from './components/Nav'
import Page from './components/Page'




function App() {

  const [maintheme, setMaintheme] = useState(false)

  function theme(e) {
    // e.preventDefault()
    setMaintheme(e)
  }

  

  

  return (
    <div  className={`App w-full h-full  flex flex-row  ${maintheme == true ? 'bg-red-50' : 'bg-slate-800'}`} style={{overflowX: 'hidden'}}>
      {/* <Nav theme={theme} str={maintheme}/> */}
      <Page theme={maintheme} mtheme={theme} />
    </div>
  )
}

export default App





